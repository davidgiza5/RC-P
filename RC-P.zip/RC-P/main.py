#main loop

from int_gr import MainInt

mainint=MainInt()
mainint.config(background="#000000")
mainint.mainloop()